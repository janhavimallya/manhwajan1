import { useState, useEffect } from "react";
import { fetchManhwaById, type Manhwa } from "@/lib/api";
import Header from "@/components/Header";
import ManhwaCard from "@/components/ManhwaCard";
import { Heart, Loader2 } from "lucide-react";

export default function Bookmarks() {
  const [bookmarks, setBookmarks] = useState<string[]>(() => {
    try { return JSON.parse(localStorage.getItem("manhwajan_bookmarks") || "[]"); } catch { return []; }
  });
  const [manhwas, setManhwas] = useState<Manhwa[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (bookmarks.length === 0) { setLoading(false); return; }
    Promise.all(bookmarks.map((id) => fetchManhwaById(id)))
      .then((results) => setManhwas(results.filter(Boolean) as Manhwa[]))
      .finally(() => setLoading(false));
  }, []);

  const handleBookmark = (id: string) => {
    setBookmarks((prev) => {
      const next = prev.filter((b) => b !== id);
      localStorage.setItem("manhwajan_bookmarks", JSON.stringify(next));
      setManhwas((m) => m.filter((mw) => mw.id !== id));
      return next;
    });
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <section className="py-16">
        <div className="container">
          <div className="mb-12">
            <h1 className="font-display text-4xl font-bold text-foreground mb-4 flex items-center gap-3">
              <Heart size={40} className="fill-accent text-accent" />
              My Bookmarks
            </h1>
            <p className="text-lg text-muted-foreground">{manhwas.length} stor{manhwas.length !== 1 ? "ies" : "y"} saved</p>
          </div>

          {loading ? (
            <div className="flex justify-center py-16"><Loader2 className="animate-spin text-accent" size={40} /></div>
          ) : manhwas.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {manhwas.map((manhwa) => (
                <ManhwaCard key={manhwa.id} manhwa={manhwa} onBookmark={handleBookmark} isBookmarked={true} />
              ))}
            </div>
          ) : (
            <div className="text-center py-16">
              <Heart size={64} className="mx-auto text-muted-foreground mb-4 opacity-50" />
              <h2 className="font-display text-2xl font-bold text-foreground mb-2">No Bookmarks Yet</h2>
              <p className="text-muted-foreground mb-8">Start bookmarking your favorite stories to see them here</p>
              <a href="/" className="inline-block px-6 py-3 bg-accent text-accent-foreground font-semibold rounded-lg hover:opacity-90 transition-smooth">
                Explore Stories
              </a>
            </div>
          )}
        </div>
      </section>
    </div>
  );
}
