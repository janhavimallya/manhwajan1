import { useState, useEffect } from "react";
import { fetchTrending, fetchLatest, fetchMangaByTag, TROPES, TROPE_TAGS, type Manhwa } from "@/lib/api";
import Header from "@/components/Header";
import ManhwaCard from "@/components/ManhwaCard";
import { Loader2 } from "lucide-react";

function Spinner() {
  return (
    <div className="flex justify-center items-center py-16">
      <Loader2 className="animate-spin text-accent" size={40} />
    </div>
  );
}

export default function Home() {
  const [bookmarks, setBookmarks] = useState<string[]>(() => {
    try { return JSON.parse(localStorage.getItem("manhwajan_bookmarks") || "[]"); }
    catch { return []; }
  });
  const [selectedTrope, setSelectedTrope] = useState<string | null>(null);
  const [trending, setTrending] = useState<Manhwa[]>([]);
  const [latest, setLatest] = useState<Manhwa[]>([]);
  const [tropeResults, setTropeResults] = useState<Manhwa[]>([]);
  const [loadingTrending, setLoadingTrending] = useState(true);
  const [loadingLatest, setLoadingLatest] = useState(true);
  const [loadingTrope, setLoadingTrope] = useState(false);

  useEffect(() => {
    fetchTrending().then(setTrending).finally(() => setLoadingTrending(false));
    fetchLatest().then(setLatest).finally(() => setLoadingLatest(false));
  }, []);

  useEffect(() => {
    if (!selectedTrope) { setTropeResults([]); return; }
    setLoadingTrope(true);
    fetchMangaByTag(TROPE_TAGS[selectedTrope], 9).then(setTropeResults).finally(() => setLoadingTrope(false));
  }, [selectedTrope]);

  const handleBookmark = (id: string) => {
    setBookmarks((prev) => {
      const next = prev.includes(id) ? prev.filter((bid) => bid !== id) : [...prev, id];
      localStorage.setItem("manhwajan_bookmarks", JSON.stringify(next));
      return next;
    });
  };

  const featuredManhwas = trending.filter((m) => m.featured);

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <section className="relative h-80 md:h-[420px] overflow-hidden bg-card">
        <div className="absolute inset-0 bg-gradient-to-r from-background via-background/70 to-transparent z-10 flex items-center">
          <div className="container z-10">
            <div className="max-w-2xl">
              <h1 className="font-display text-4xl md:text-5xl font-bold text-foreground mb-4">
                Discover Your Next<br />Favorite Story
              </h1>
              <p className="text-lg text-muted-foreground mb-8">
                Explore trending BL manhwa, find hidden gems, and dive into worlds of romance, drama, and emotion.
              </p>
              <a href="/search" className="inline-block px-8 py-3 bg-accent text-accent-foreground font-semibold rounded-lg hover:opacity-90 transition-smooth">
                Browse All Manhwa
              </a>
            </div>
          </div>
        </div>
        <div className="absolute right-0 top-0 w-1/2 h-full bg-gradient-to-l from-accent/10 to-transparent" />
        <div className="absolute bottom-0 left-0 right-0 h-24 bg-gradient-to-t from-background to-transparent z-10" />
      </section>

      <section className="py-16 bg-card/50">
        <div className="container">
          <h2 className="font-display text-3xl font-bold text-foreground mb-8">Featured This Week</h2>
          {loadingTrending ? <Spinner /> : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {featuredManhwas.slice(0, 4).map((manhwa) => (
                <ManhwaCard key={manhwa.id} manhwa={manhwa} onBookmark={handleBookmark} isBookmarked={bookmarks.includes(manhwa.id)} />
              ))}
            </div>
          )}
        </div>
      </section>

      <section className="py-16">
        <div className="container">
          <h2 className="font-display text-3xl font-bold text-foreground mb-8">Trending Now</h2>
          {loadingTrending ? <Spinner /> : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {trending.slice(0, 8).map((manhwa) => (
                <ManhwaCard key={manhwa.id} manhwa={manhwa} onBookmark={handleBookmark} isBookmarked={bookmarks.includes(manhwa.id)} />
              ))}
            </div>
          )}
        </div>
      </section>

      <section className="py-16 bg-card/50">
        <div className="container">
          <h2 className="font-display text-3xl font-bold text-foreground mb-8">Explore by Genre</h2>
          <div className="flex flex-wrap gap-3 mb-12">
            {TROPES.map((trope) => (
              <button
                key={trope}
                onClick={() => setSelectedTrope(selectedTrope === trope ? null : trope)}
                className={`px-5 py-2 rounded-full font-semibold text-sm transition-smooth ${
                  selectedTrope === trope ? "bg-accent text-accent-foreground shadow-medium" : "bg-secondary text-foreground hover:bg-secondary/80"
                }`}
              >
                {trope}
              </button>
            ))}
          </div>
          {selectedTrope && (
            <div>
              <h3 className="font-display text-2xl font-bold text-foreground mb-6">{selectedTrope} Stories</h3>
              {loadingTrope ? <Spinner /> : (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                  {tropeResults.map((manhwa) => (
                    <ManhwaCard key={manhwa.id} manhwa={manhwa} onBookmark={handleBookmark} isBookmarked={bookmarks.includes(manhwa.id)} />
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      </section>

      <section className="py-16">
        <div className="container">
          <h2 className="font-display text-3xl font-bold text-foreground mb-8">Latest Updates</h2>
          {loadingLatest ? <Spinner /> : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {latest.slice(0, 8).map((manhwa) => (
                <ManhwaCard key={manhwa.id} manhwa={manhwa} onBookmark={handleBookmark} isBookmarked={bookmarks.includes(manhwa.id)} />
              ))}
            </div>
          )}
        </div>
      </section>

      <footer className="bg-card border-t border-border py-12">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div>
              <h3 className="font-display font-bold text-foreground mb-4">Manhwajan</h3>
              <p className="text-muted-foreground text-sm">Your ultimate destination for BL manhwa discovery and reading.</p>
            </div>
            <div>
              <h4 className="font-semibold text-foreground mb-4">Explore</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="/search" className="hover:text-accent transition-smooth">Browse All</a></li>
                <li><a href="/bookmarks" className="hover:text-accent transition-smooth">Bookmarks</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-foreground mb-4">Data Source</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="https://mangadex.org" target="_blank" rel="noopener noreferrer" className="hover:text-accent transition-smooth">MangaDex</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-foreground mb-4">Legal</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-accent transition-smooth">Privacy Policy</a></li>
                <li><a href="#" className="hover:text-accent transition-smooth">Terms of Service</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-border pt-8 text-center text-sm text-muted-foreground">
            <p>© 2024 Manhwajan. All rights reserved. | Made with ❤️ for BL enthusiasts | Powered by MangaDex API</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
