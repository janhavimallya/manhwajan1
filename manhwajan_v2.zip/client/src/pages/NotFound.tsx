import { Link } from "wouter";
import Header from "@/components/Header";

export default function NotFound() {
  return (
    <div className="min-h-screen bg-background">
      <Header />

      <div className="flex items-center justify-center py-32 px-4">
        <div className="text-center max-w-md">
          <h1 className="font-display text-6xl font-bold text-accent mb-4">
            404
          </h1>
          <h2 className="font-display text-3xl font-bold text-foreground mb-4">
            Page Not Found
          </h2>
          <p className="text-muted-foreground mb-8">
            The page you're looking for doesn't exist or has been moved.
          </p>
          <Link href="/">
            <a className="inline-block px-6 py-3 bg-accent text-accent-foreground font-semibold rounded-lg hover:opacity-90 transition-smooth">
              Go Home
            </a>
          </Link>
        </div>
      </div>
    </div>
  );
}
