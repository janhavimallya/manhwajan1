import { useState, useEffect, useCallback } from "react";
import { useLocation } from "wouter";
import { searchManhwa, TROPES, TROPE_TAGS, type Manhwa } from "@/lib/api";
import Header from "@/components/Header";
import ManhwaCard from "@/components/ManhwaCard";
import { X, Loader2, Search as SearchIcon } from "lucide-react";

function Spinner() {
  return <div className="flex justify-center items-center py-16"><Loader2 className="animate-spin text-accent" size={40} /></div>;
}

export default function Search() {
  const [location] = useLocation();
  const params = new URLSearchParams(location.includes("?") ? location.split("?")[1] : "");
  const initialQuery = params.get("q") || "";

  const [bookmarks, setBookmarks] = useState<string[]>(() => {
    try { return JSON.parse(localStorage.getItem("manhwajan_bookmarks") || "[]"); } catch { return []; }
  });
  const [query, setQuery] = useState(initialQuery);
  const [inputValue, setInputValue] = useState(initialQuery);
  const [selectedTrope, setSelectedTrope] = useState<string | null>(null);
  const [results, setResults] = useState<Manhwa[]>([]);
  const [loading, setLoading] = useState(false);
  const [searched, setSearched] = useState(false);

  const doSearch = useCallback(async (q: string, trope: string | null) => {
    setLoading(true);
    setSearched(true);
    const tags = trope ? [TROPE_TAGS[trope]] : [];
    const data = await searchManhwa(q, tags);
    setResults(data);
    setLoading(false);
  }, []);

  useEffect(() => {
    if (initialQuery) doSearch(initialQuery, null);
  }, []);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setQuery(inputValue);
    doSearch(inputValue, selectedTrope);
  };

  const handleTrope = (trope: string) => {
    const next = selectedTrope === trope ? null : trope;
    setSelectedTrope(next);
    doSearch(query, next);
  };

  const handleBookmark = (id: string) => {
    setBookmarks((prev) => {
      const next = prev.includes(id) ? prev.filter((b) => b !== id) : [...prev, id];
      localStorage.setItem("manhwajan_bookmarks", JSON.stringify(next));
      return next;
    });
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <section className="py-12">
        <div className="container">
          <h1 className="font-display text-3xl font-bold text-foreground mb-6">Search Manhwa</h1>

          <form onSubmit={handleSearch} className="flex gap-3 mb-8">
            <div className="flex-1 flex items-center gap-2 bg-secondary rounded-lg px-4 py-3">
              <SearchIcon size={18} className="text-muted-foreground flex-shrink-0" />
              <input
                type="text"
                placeholder="Search by title, author..."
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                className="flex-1 bg-transparent outline-none text-foreground placeholder:text-muted-foreground"
                autoFocus
              />
              {inputValue && (
                <button type="button" onClick={() => setInputValue("")}>
                  <X size={16} className="text-muted-foreground hover:text-foreground" />
                </button>
              )}
            </div>
            <button type="submit" className="px-6 py-3 bg-accent text-accent-foreground font-semibold rounded-lg hover:opacity-90 transition-smooth">
              Search
            </button>
          </form>

          <div className="mb-8">
            <p className="text-sm font-semibold text-foreground mb-3">Filter by Genre</p>
            <div className="flex flex-wrap gap-2">
              <button
                onClick={() => { setSelectedTrope(null); if (query) doSearch(query, null); }}
                className={`px-4 py-2 rounded-full text-sm font-semibold transition-smooth ${selectedTrope === null ? "bg-accent text-accent-foreground" : "bg-secondary text-foreground hover:bg-secondary/80"}`}
              >
                All
              </button>
              {TROPES.map((trope) => (
                <button
                  key={trope}
                  onClick={() => handleTrope(trope)}
                  className={`px-4 py-2 rounded-full text-sm font-semibold transition-smooth ${selectedTrope === trope ? "bg-accent text-accent-foreground" : "bg-secondary text-foreground hover:bg-secondary/80"}`}
                >
                  {trope}
                </button>
              ))}
            </div>
          </div>

          {loading ? <Spinner /> : searched ? (
            results.length > 0 ? (
              <>
                <p className="text-muted-foreground mb-6">Found {results.length} result{results.length !== 1 ? "s" : ""}{query ? ` for "${query}"` : ""}</p>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                  {results.map((manhwa) => (
                    <ManhwaCard key={manhwa.id} manhwa={manhwa} onBookmark={handleBookmark} isBookmarked={bookmarks.includes(manhwa.id)} />
                  ))}
                </div>
              </>
            ) : (
              <div className="text-center py-16">
                <X size={64} className="mx-auto text-muted-foreground mb-4 opacity-50" />
                <h2 className="font-display text-2xl font-bold text-foreground mb-2">No Results Found</h2>
                <p className="text-muted-foreground">Try adjusting your search terms or filters</p>
              </div>
            )
          ) : (
            <div className="text-center py-16 text-muted-foreground">
              <SearchIcon size={48} className="mx-auto mb-4 opacity-30" />
              <p>Search for your favorite manhwa above</p>
            </div>
          )}
        </div>
      </section>
    </div>
  );
}
