import { useState, useEffect } from "react";
import { useRoute, useLocation } from "wouter";
import { Heart, BookOpen, ChevronLeft, ExternalLink, Loader2 } from "lucide-react";
import { fetchManhwaById, fetchChapters, type Manhwa, type Chapter } from "@/lib/api";
import Header from "@/components/Header";

function Spinner() {
  return <div className="flex justify-center items-center py-16"><Loader2 className="animate-spin text-accent" size={40} /></div>;
}

export default function ManhwaDetail() {
  const [, params] = useRoute("/manhwa/:id");
  const [, navigate] = useLocation();
  const [manhwa, setManhwa] = useState<Manhwa | null>(null);
  const [chapters, setChapters] = useState<Chapter[]>([]);
  const [loading, setLoading] = useState(true);
  const [isBookmarked, setIsBookmarked] = useState(false);

  const id = params?.id || "";

  useEffect(() => {
    if (!id) return;
    setLoading(true);
    Promise.all([fetchManhwaById(id), fetchChapters(id)])
      .then(([m, chs]) => {
        setManhwa(m);
        setChapters(chs);
        const saved = JSON.parse(localStorage.getItem("manhwajan_bookmarks") || "[]");
        setIsBookmarked(saved.includes(id));
      })
      .finally(() => setLoading(false));
  }, [id]);

  const toggleBookmark = () => {
    const saved: string[] = JSON.parse(localStorage.getItem("manhwajan_bookmarks") || "[]");
    const next = isBookmarked ? saved.filter((b) => b !== id) : [...saved, id];
    localStorage.setItem("manhwajan_bookmarks", JSON.stringify(next));
    setIsBookmarked(!isBookmarked);
  };

  if (loading) return <div className="min-h-screen bg-background"><Header /><Spinner /></div>;

  if (!manhwa) return (
    <div className="min-h-screen bg-background"><Header />
      <div className="container py-16 text-center">
        <h1 className="font-display text-3xl font-bold text-foreground mb-4">Manhwa Not Found</h1>
        <button onClick={() => navigate("/")} className="px-6 py-3 bg-accent text-accent-foreground rounded-lg font-semibold">Go Home</button>
      </div>
    </div>
  );

  const mangaDexUrl = `https://mangadex.org/title/${manhwa.id}`;
  const firstChapter = chapters[chapters.length - 1];

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <section className="relative py-12 bg-card/50">
        <div className="container">
          <button onClick={() => navigate("/")} className="flex items-center gap-2 text-muted-foreground hover:text-accent transition-smooth mb-6">
            <ChevronLeft size={18} /> Back
          </button>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="flex justify-center md:justify-start">
              <div className="relative w-52 h-80 rounded-lg overflow-hidden shadow-deep bg-muted">
                <img src={manhwa.cover} alt={manhwa.title} className="w-full h-full object-cover" onError={(e) => { (e.target as HTMLImageElement).src = "https://via.placeholder.com/208x320/1a1928/e8708a?text=No+Cover"; }} />
              </div>
            </div>

            <div className="md:col-span-2">
              <div className="flex items-start gap-3 mb-2">
                <span className={`px-3 py-1 rounded-full text-xs font-semibold text-white ${manhwa.status === "ongoing" ? "bg-accent" : manhwa.status === "completed" ? "bg-green-600" : "bg-muted-foreground"}`}>
                  {manhwa.status.charAt(0).toUpperCase() + manhwa.status.slice(1)}
                </span>
              </div>
              <h1 className="font-display text-3xl md:text-4xl font-bold text-foreground mb-2">{manhwa.title}</h1>
              <p className="text-lg text-accent mb-4">{manhwa.author}</p>

              <div className="flex flex-wrap gap-2 mb-6">
                {manhwa.tags.slice(0, 6).map((tag) => (
                  <span key={tag} className="px-3 py-1 rounded-full bg-secondary text-secondary-foreground text-sm font-medium">{tag}</span>
                ))}
              </div>

              <p className="text-foreground leading-relaxed mb-6 line-clamp-4">{manhwa.summary}</p>

              <div className="flex flex-wrap gap-3">
                {firstChapter ? (
                  <a
                    href={`https://mangadex.org/chapter/${firstChapter.id}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-2 px-6 py-3 bg-accent text-accent-foreground font-semibold rounded-lg hover:opacity-90 transition-smooth"
                  >
                    <BookOpen size={20} /> Start Reading
                  </a>
                ) : null}
                <button
                  onClick={toggleBookmark}
                  className={`flex items-center gap-2 px-6 py-3 rounded-lg font-semibold transition-smooth ${isBookmarked ? "bg-accent text-accent-foreground" : "bg-secondary text-foreground hover:bg-secondary/80"}`}
                >
                  <Heart size={20} className={isBookmarked ? "fill-current" : ""} />
                  {isBookmarked ? "Bookmarked" : "Bookmark"}
                </button>
                <a
                  href={mangaDexUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 px-6 py-3 bg-secondary text-foreground font-semibold rounded-lg hover:bg-secondary/80 transition-smooth"
                >
                  <ExternalLink size={20} /> View on MangaDex
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-12">
        <div className="container max-w-3xl">
          <h2 className="font-display text-2xl font-bold text-foreground mb-4">Summary</h2>
          <p className="text-foreground leading-relaxed">{manhwa.summary}</p>
        </div>
      </section>

      {chapters.length > 0 && (
        <section className="py-12 bg-card/50">
          <div className="container max-w-3xl">
            <h2 className="font-display text-2xl font-bold text-foreground mb-6">
              Chapters ({chapters.length})
            </h2>
            <div className="space-y-2">
              {chapters.slice(0, 50).map((chapter) => (
                <a
                  key={chapter.id}
                  href={`https://mangadex.org/chapter/${chapter.id}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-between p-4 bg-card rounded-lg hover:shadow-medium transition-smooth cursor-pointer group border border-transparent hover:border-accent/30"
                >
                  <div className="flex-1">
                    <h3 className="font-semibold text-foreground group-hover:text-accent transition-smooth">
                      Chapter {chapter.number}{chapter.title && chapter.title !== `Chapter ${chapter.number}` ? `: ${chapter.title}` : ""}
                    </h3>
                    <p className="text-sm text-muted-foreground">{chapter.uploadedAt}</p>
                  </div>
                  <ExternalLink size={16} className="text-muted-foreground group-hover:text-accent transition-smooth" />
                </a>
              ))}
              {chapters.length > 50 && (
                <p className="text-center text-muted-foreground text-sm pt-4">
                  +{chapters.length - 50} more chapters on <a href={mangaDexUrl} target="_blank" rel="noopener noreferrer" className="text-accent hover:underline">MangaDex</a>
                </p>
              )}
            </div>
          </div>
        </section>
      )}

      <footer className="bg-card border-t border-border py-8">
        <div className="container text-center text-muted-foreground text-sm">
          <p>© 2024 Manhwajan. Data powered by <a href="https://mangadex.org" target="_blank" rel="noopener noreferrer" className="text-accent hover:underline">MangaDex</a>.</p>
        </div>
      </footer>
    </div>
  );
}
