import { Heart } from "lucide-react";
import { useState } from "react";
import { type Manhwa } from "@/lib/api";
import { Link } from "wouter";

interface ManhwaCardProps {
  manhwa: Manhwa;
  onBookmark?: (id: string) => void;
  isBookmarked?: boolean;
}

export default function ManhwaCard({ manhwa, onBookmark, isBookmarked = false }: ManhwaCardProps) {
  const [isHovered, setIsHovered] = useState(false);
  const [imgError, setImgError] = useState(false);

  return (
    <Link href={`/manhwa/${manhwa.id}`}>
      <a className="block h-full">
        <div
          className="relative overflow-hidden rounded-lg bg-card shadow-soft transition-smooth hover:shadow-medium cursor-pointer h-full flex flex-col"
          onMouseEnter={() => setIsHovered(true)}
          onMouseLeave={() => setIsHovered(false)}
        >
          <div className="relative w-full aspect-[2/3] overflow-hidden bg-muted">
            <img
              src={imgError ? "https://via.placeholder.com/300x450/1a1928/e8708a?text=No+Cover" : manhwa.cover}
              alt={manhwa.title}
              className="w-full h-full object-cover transition-smooth duration-300"
              style={{ transform: isHovered ? "scale(1.05)" : "scale(1)" }}
              onError={() => setImgError(true)}
            />
            <div className="gradient-overlay absolute inset-0" />

            <div className="absolute top-3 right-3">
              <span className={`px-3 py-1 rounded-full text-xs font-semibold text-white ${
                manhwa.status === "ongoing" ? "bg-accent" :
                manhwa.status === "completed" ? "bg-green-600" : "bg-muted-foreground"
              }`}>
                {manhwa.status.charAt(0).toUpperCase() + manhwa.status.slice(1)}
              </span>
            </div>

            <button
              onClick={(e) => { e.preventDefault(); onBookmark?.(manhwa.id); }}
              className="absolute top-3 left-3 p-2 rounded-full bg-white/80 backdrop-blur-sm hover:bg-white transition-smooth"
            >
              <Heart size={18} className={`transition-smooth ${isBookmarked ? "fill-accent text-accent" : "text-muted-foreground"}`} />
            </button>

            {manhwa.featured && (
              <div className="absolute bottom-3 left-3">
                <span className="px-2 py-1 rounded text-xs font-semibold text-accent bg-white/90 backdrop-blur-sm">Featured</span>
              </div>
            )}
          </div>

          <div className="flex-1 p-4 flex flex-col justify-between">
            <div>
              <h3 className="font-display text-base font-bold text-foreground mb-1 line-clamp-2">{manhwa.title}</h3>
              <p className="text-sm text-muted-foreground mb-3">{manhwa.author}</p>
              <div className="flex flex-wrap gap-1 mb-3">
                {manhwa.tags.slice(0, 2).map((tag) => (
                  <span key={tag} className="text-xs px-2 py-1 rounded-full bg-secondary text-secondary-foreground">{tag}</span>
                ))}
                {manhwa.tags.length > 2 && (
                  <span className="text-xs px-2 py-1 text-muted-foreground">+{manhwa.tags.length - 2}</span>
                )}
              </div>
            </div>
            <div className="flex items-center justify-between text-xs text-muted-foreground border-t border-border pt-3">
              <span>⭐ {manhwa.rating}</span>
              {manhwa.chapters > 0 && <span>{manhwa.chapters} ch.</span>}
            </div>
          </div>
        </div>
      </a>
    </Link>
  );
}
