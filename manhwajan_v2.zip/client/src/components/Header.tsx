import { Menu, Moon, Search, Sun, X, BookmarkIcon } from "lucide-react";
import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useTheme } from "@/contexts/ThemeContext";

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [searchInput, setSearchInput] = useState("");
  const { theme, toggleTheme } = useTheme();
  const [, navigate] = useLocation();

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchInput.trim()) navigate(`/search?q=${encodeURIComponent(searchInput.trim())}`);
    else navigate("/search");
    setIsMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-50 bg-card/95 backdrop-blur-sm border-b border-border shadow-soft">
      <div className="container">
        <div className="flex items-center justify-between py-4">
          <Link href="/">
            <a className="flex items-center gap-2 transition-smooth hover:opacity-80">
              <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-accent to-accent/60 flex items-center justify-center">
                <span className="font-display font-bold text-white text-lg">M</span>
              </div>
              <span className="font-display font-bold text-xl text-foreground hidden sm:inline">Manhwajan</span>
            </a>
          </Link>

          <form onSubmit={handleSearch} className="hidden md:flex flex-1 mx-8 items-center gap-2 bg-secondary rounded-lg px-4 py-2">
            <Search size={18} className="text-muted-foreground" />
            <input
              type="text"
              placeholder="Search manhwa..."
              value={searchInput}
              onChange={(e) => setSearchInput(e.target.value)}
              className="flex-1 bg-transparent outline-none text-foreground placeholder:text-muted-foreground"
            />
          </form>

          <div className="flex items-center gap-3">
            <button onClick={toggleTheme} className="p-2 rounded-lg hover:bg-secondary transition-smooth" aria-label="Toggle dark mode">
              {theme === "light" ? <Moon size={20} className="text-muted-foreground" /> : <Sun size={20} className="text-muted-foreground" />}
            </button>
            <Link href="/bookmarks">
              <a className="p-2 rounded-lg hover:bg-secondary transition-smooth" aria-label="Bookmarks">
                <BookmarkIcon size={20} className="text-muted-foreground" />
              </a>
            </Link>
            <button onClick={() => setIsMenuOpen(!isMenuOpen)} className="md:hidden p-2 rounded-lg hover:bg-secondary transition-smooth" aria-label="Toggle menu">
              {isMenuOpen ? <X size={20} className="text-foreground" /> : <Menu size={20} className="text-foreground" />}
            </button>
          </div>
        </div>

        <form onSubmit={handleSearch} className="md:hidden mb-4 flex items-center gap-2 bg-secondary rounded-lg px-4 py-2">
          <Search size={18} className="text-muted-foreground" />
          <input
            type="text"
            placeholder="Search manhwa..."
            value={searchInput}
            onChange={(e) => setSearchInput(e.target.value)}
            className="flex-1 bg-transparent outline-none text-foreground placeholder:text-muted-foreground"
          />
        </form>

        {isMenuOpen && (
          <nav className="md:hidden pb-4 space-y-2 border-t border-border pt-4">
            <Link href="/"><a onClick={() => setIsMenuOpen(false)} className="block px-4 py-2 rounded-lg hover:bg-secondary transition-smooth text-foreground">Home</a></Link>
            <Link href="/search"><a onClick={() => setIsMenuOpen(false)} className="block px-4 py-2 rounded-lg hover:bg-secondary transition-smooth text-foreground">Browse</a></Link>
            <Link href="/bookmarks"><a onClick={() => setIsMenuOpen(false)} className="block px-4 py-2 rounded-lg hover:bg-secondary transition-smooth text-foreground">Bookmarks</a></Link>
          </nav>
        )}
      </div>
    </header>
  );
}
