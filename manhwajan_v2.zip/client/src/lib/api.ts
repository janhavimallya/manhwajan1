// MangaDex Public API – no auth required
// Docs: https://api.mangadex.org/docs/

const BASE = "https://api.mangadex.org";
const COVER_CDN = "https://uploads.mangadex.org/covers";

export interface Manhwa {
  id: string;
  title: string;
  author: string;
  cover: string;
  rating: number;
  views: number;
  chapters: number;
  status: "ongoing" | "completed" | "hiatus" | "cancelled";
  summary: string;
  tags: string[];
  tropes: string[];
  updatedAt: string;
  featured?: boolean;
}

export interface Chapter {
  id: string;
  number: string;
  title: string;
  uploadedAt: string;
  views: number;
  lang: string;
}

export interface Comment {
  id: string;
  author: string;
  avatar: string;
  content: string;
  timestamp: string;
  likes: number;
  replies?: Comment[];
}

// ── Helpers ──────────────────────────────────────────────

function getTitle(attrs: any): string {
  return (
    attrs.title?.en ||
    attrs.title?.["ja-ro"] ||
    attrs.title?.ja ||
    Object.values(attrs.title || {})[0] ||
    "Unknown Title"
  );
}

function getDescription(attrs: any): string {
  return (
    attrs.description?.en ||
    attrs.description?.["ja-ro"] ||
    Object.values(attrs.description || {})[0] ||
    "No description available."
  );
}

function getCoverUrl(manga: any): string {
  const rel = manga.relationships?.find((r: any) => r.type === "cover_art");
  if (rel?.attributes?.fileName) {
    return `${COVER_CDN}/${manga.id}/${rel.attributes.fileName}.512.jpg`;
  }
  return `https://via.placeholder.com/300x450/1a1928/e8708a?text=No+Cover`;
}

function getAuthor(manga: any): string {
  const rel = manga.relationships?.find(
    (r: any) => r.type === "author" || r.type === "artist"
  );
  return rel?.attributes?.name || "Unknown Author";
}

function parseManga(manga: any): Manhwa {
  const attrs = manga.attributes;
  const tags = (attrs.tags || []).map((t: any) => t.attributes?.name?.en).filter(Boolean);
  return {
    id: manga.id,
    title: getTitle(attrs),
    author: getAuthor(manga),
    cover: getCoverUrl(manga),
    rating: parseFloat((Math.random() * 1.5 + 3.5).toFixed(1)), // stat not on public api
    views: Math.floor(Math.random() * 3000000) + 200000,
    chapters: attrs.lastChapter ? parseInt(attrs.lastChapter) || 0 : 0,
    status: attrs.status || "ongoing",
    summary: getDescription(attrs),
    tags,
    tropes: tags.slice(0, 3),
    updatedAt: attrs.updatedAt?.slice(0, 10) || new Date().toISOString().slice(0, 10),
    featured: false,
  };
}

// ── API Calls ─────────────────────────────────────────────

const INCLUDES = ["cover_art", "author", "artist"].join("&includes[]=");

// BL / boys-love tag IDs on MangaDex
const BL_TAG = "5920b825-4181-4a17-befd-0de3d0d9b19d"; // Boys' Love
const MANHWA_ORIGIN = "ko"; // Korean origin = manhwa

async function fetchJSON(url: string): Promise<any> {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`API error ${res.status}`);
  return res.json();
}

export async function fetchTrending(): Promise<Manhwa[]> {
  const url = `${BASE}/manga?limit=12&publicationDemographic[]=josei&publicationDemographic[]=shoujo&tags[]=5920b825-4181-4a17-befd-0de3d0d9b19d&originalLanguage[]=${MANHWA_ORIGIN}&includes[]=${INCLUDES}&order[followedCount]=desc&contentRating[]=safe&contentRating[]=suggestive`;
  const data = await fetchJSON(url);
  const items = (data.data || []).map(parseManga);
  // Mark first 4 as featured
  items.slice(0, 4).forEach((m: Manhwa, i: number) => {
    m.featured = i < 4;
  });
  return items;
}

export async function fetchLatest(): Promise<Manhwa[]> {
  const url = `${BASE}/manga?limit=12&originalLanguage[]=${MANHWA_ORIGIN}&tags[]=${BL_TAG}&includes[]=${INCLUDES}&order[updatedAt]=desc&contentRating[]=safe&contentRating[]=suggestive`;
  const data = await fetchJSON(url);
  return (data.data || []).map(parseManga);
}

export async function searchManhwa(query: string, tags?: string[]): Promise<Manhwa[]> {
  let url = `${BASE}/manga?limit=20&originalLanguage[]=${MANHWA_ORIGIN}&includes[]=${INCLUDES}&contentRating[]=safe&contentRating[]=suggestive&order[relevance]=desc`;
  if (query) url += `&title=${encodeURIComponent(query)}`;
  if (tags?.length) url += tags.map((t) => `&tags[]=${t}`).join("");
  const data = await fetchJSON(url);
  return (data.data || []).map(parseManga);
}

export async function fetchManhwaById(id: string): Promise<Manhwa | null> {
  try {
    const url = `${BASE}/manga/${id}?includes[]=${INCLUDES}`;
    const data = await fetchJSON(url);
    return parseManga(data.data);
  } catch {
    return null;
  }
}

export async function fetchChapters(mangaId: string): Promise<Chapter[]> {
  const url = `${BASE}/manga/${mangaId}/feed?limit=100&translatedLanguage[]=en&order[chapter]=desc&contentRating[]=safe&contentRating[]=suggestive`;
  try {
    const data = await fetchJSON(url);
    return (data.data || []).map((ch: any) => ({
      id: ch.id,
      number: ch.attributes.chapter || "?",
      title: ch.attributes.title || `Chapter ${ch.attributes.chapter}`,
      uploadedAt: ch.attributes.publishAt?.slice(0, 10) || "",
      views: 0,
      lang: ch.attributes.translatedLanguage || "en",
    }));
  } catch {
    return [];
  }
}

export async function fetchChapterPages(chapterId: string): Promise<string[]> {
  const url = `${BASE}/at-home/server/${chapterId}`;
  const data = await fetchJSON(url);
  const base = data.baseUrl;
  const hash = data.chapter?.hash;
  const pages = data.chapter?.data || [];
  return pages.map((p: string) => `${base}/data/${hash}/${p}`);
}

export async function fetchMangaByTag(tagId: string, limit = 6): Promise<Manhwa[]> {
  const url = `${BASE}/manga?limit=${limit}&tags[]=${tagId}&originalLanguage[]=${MANHWA_ORIGIN}&includes[]=${INCLUDES}&order[followedCount]=desc&contentRating[]=safe&contentRating[]=suggestive`;
  const data = await fetchJSON(url);
  return (data.data || []).map(parseManga);
}

// Common BL trope tag IDs on MangaDex
export const TROPE_TAGS: Record<string, string> = {
  "Boys' Love":    BL_TAG,
  "Slice of Life": "e5301a23-ebd9-49dd-a0cb-2add944c7fe9",
  "Romance":       "423e2eae-a7a2-4a8b-ac03-a8351462d71d",
  "Drama":         "b9af3a63-f058-46de-a9a0-e0c13906197a",
  "Comedy":        "4d32cc48-9f00-4cca-9b5a-a839f0764984",
  "School Life":   "caaa44eb-cd40-4177-b930-79d3ef2afe87",
  "Fantasy":       "cdc58593-87dd-415e-bbc0-2ec27bf404cc",
  "Action":        "391b0423-d847-456f-aff0-8b0cfc03066b",
};

export const TROPES = Object.keys(TROPE_TAGS);
