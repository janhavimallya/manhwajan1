// Dummy data for BL Manhwa Hub
export interface Manhwa {
  id: string;
  title: string;
  author: string;
  cover: string;
  rating: number;
  views: number;
  chapters: number;
  status: "ongoing" | "completed";
  summary: string;
  tags: string[];
  tropes: string[];
  updatedAt: string;
  featured?: boolean;
}

export interface Chapter {
  id: string;
  number: number;
  title: string;
  uploadedAt: string;
  views: number;
}

export interface Comment {
  id: string;
  author: string;
  avatar: string;
  content: string;
  timestamp: string;
  likes: number;
  replies?: Comment[];
}

export const CATEGORIES = [
  { id: "romance", name: "Romance", icon: "heart" },
  { id: "enemies-to-lovers", name: "Enemies to Lovers", icon: "zap" },
  { id: "slow-burn", name: "Slow Burn", icon: "flame" },
  { id: "school-life", name: "School Life", icon: "book" },
  { id: "supernatural", name: "Supernatural", icon: "sparkles" },
  { id: "comedy", name: "Comedy", icon: "smile" },
  { id: "drama", name: "Drama", icon: "theater" },
  { id: "action", name: "Action", icon: "zap" },
];

export const TROPES = [
  "Enemies to Lovers",
  "Slow Burn",
  "Jealousy",
  "Protective",
  "Tsundere",
  "Unrequited Love",
  "Second Chances",
  "Forced Proximity",
  "Childhood Friends",
  "Forbidden Love",
  "College/University",
  "Office Romance",
];

export const MANHWAS: Manhwa[] = [
  {
    id: "1",
    title: "Crimson Love",
    author: "Lee Min-jun",
    cover: "https://d2xsxph8kpxj0f.cloudfront.net/310519663623124315/kJ8pPWeKnuTcJ4oZK2N7Gs/cover-1-9HA4SonVh3NBgNJA8MMhxM.webp",
    rating: 4.8,
    views: 2500000,
    chapters: 156,
    status: "ongoing",
    summary: "A passionate tale of two rival gang leaders who discover love in the most unexpected way. Filled with action, romance, and emotional depth.",
    tags: ["romance", "action", "drama"],
    tropes: ["Enemies to Lovers", "Protective", "Jealousy"],
    updatedAt: "2024-05-02",
    featured: true,
  },
  {
    id: "2",
    title: "Moonlit Secrets",
    author: "Park Ji-woo",
    cover: "https://d2xsxph8kpxj0f.cloudfront.net/310519663623124315/kJ8pPWeKnuTcJ4oZK2N7Gs/cover-2-2JB9xawwiq5whhQZSupWZV.webp",
    rating: 4.6,
    views: 1800000,
    chapters: 89,
    status: "ongoing",
    summary: "A supernatural romance between a human and a mysterious being from another world. Secrets, magic, and forbidden love intertwine.",
    tags: ["romance", "supernatural", "mystery"],
    tropes: ["Forbidden Love", "Slow Burn", "Protective"],
    updatedAt: "2024-05-01",
    featured: true,
  },
  {
    id: "3",
    title: "Campus Hearts",
    author: "Kim Tae-oh",
    cover: "https://d2xsxph8kpxj0f.cloudfront.net/310519663623124315/kJ8pPWeKnuTcJ4oZK2N7Gs/cover-3-hPvvZf5mM8xtuNcnwpqgKH.webp",
    rating: 4.5,
    views: 1600000,
    chapters: 124,
    status: "ongoing",
    summary: "Two college students from different worlds collide on campus. A heartwarming story of acceptance, growth, and unexpected love.",
    tags: ["romance", "school-life", "comedy"],
    tropes: ["Childhood Friends", "Slow Burn", "Unrequited Love"],
    updatedAt: "2024-04-30",
    featured: true,
  },
  {
    id: "4",
    title: "Midnight Confessions",
    author: "Choi Sung-ho",
    cover: "https://images.unsplash.com/photo-1516979187457-635ffe35ebda?w=300&h=450&fit=crop",
    rating: 4.7,
    views: 2100000,
    chapters: 98,
    status: "completed",
    summary: "Late-night conversations between two strangers turn into something deeper. A poignant exploration of connection and vulnerability.",
    tags: ["romance", "drama", "slice-of-life"],
    tropes: ["Slow Burn", "Second Chances", "Emotional"],
    updatedAt: "2024-03-15",
  },
  {
    id: "5",
    title: "Burning Desire",
    author: "Oh Se-jun",
    cover: "https://images.unsplash.com/photo-1516979187457-635ffe35ebda?w=300&h=450&fit=crop",
    rating: 4.4,
    views: 1400000,
    chapters: 67,
    status: "ongoing",
    summary: "A passionate story of two men who can't resist each other despite their differences. Intense emotions and steamy romance.",
    tags: ["romance", "drama"],
    tropes: ["Enemies to Lovers", "Jealousy", "Protective"],
    updatedAt: "2024-05-02",
  },
  {
    id: "6",
    title: "Starlight Promise",
    author: "Han Ji-min",
    cover: "https://images.unsplash.com/photo-1516979187457-635ffe35ebda?w=300&h=450&fit=crop",
    rating: 4.9,
    views: 3000000,
    chapters: 145,
    status: "ongoing",
    summary: "Under the stars, two souls make a promise that changes everything. A beautiful journey of love, sacrifice, and redemption.",
    tags: ["romance", "drama", "supernatural"],
    tropes: ["Slow Burn", "Protective", "Forbidden Love"],
    updatedAt: "2024-05-02",
    featured: true,
  },
  {
    id: "7",
    title: "Office Obsession",
    author: "Kang Min-soo",
    cover: "https://images.unsplash.com/photo-1516979187457-635ffe35ebda?w=300&h=450&fit=crop",
    rating: 4.3,
    views: 1200000,
    chapters: 56,
    status: "ongoing",
    summary: "Two coworkers navigate professional boundaries and personal desires. A witty and steamy office romance with unexpected twists.",
    tags: ["romance", "comedy", "drama"],
    tropes: ["Office Romance", "Tsundere", "Jealousy"],
    updatedAt: "2024-04-28",
  },
  {
    id: "8",
    title: "Echoes of Yesterday",
    author: "Lee Soo-jin",
    cover: "https://images.unsplash.com/photo-1516979187457-635ffe35ebda?w=300&h=450&fit=crop",
    rating: 4.6,
    views: 1700000,
    chapters: 102,
    status: "completed",
    summary: "A reunion between two former lovers brings back memories and unresolved feelings. Can they rewrite their story?",
    tags: ["romance", "drama"],
    tropes: ["Second Chances", "Unrequited Love", "Slow Burn"],
    updatedAt: "2024-02-20",
  },
];

export const CHAPTERS: Record<string, Chapter[]> = {
  "1": [
    { id: "1-1", number: 1, title: "The Beginning", uploadedAt: "2024-01-01", views: 450000 },
    { id: "1-2", number: 2, title: "First Encounter", uploadedAt: "2024-01-08", views: 420000 },
    { id: "1-3", number: 3, title: "Unexpected Feelings", uploadedAt: "2024-01-15", views: 410000 },
    { id: "1-4", number: 4, title: "Secrets Revealed", uploadedAt: "2024-01-22", views: 395000 },
    { id: "1-5", number: 5, title: "The Truth", uploadedAt: "2024-01-29", views: 380000 },
  ],
  "2": [
    { id: "2-1", number: 1, title: "Moonlight", uploadedAt: "2024-02-01", views: 380000 },
    { id: "2-2", number: 2, title: "Mysterious Stranger", uploadedAt: "2024-02-08", views: 360000 },
    { id: "2-3", number: 3, title: "Hidden Powers", uploadedAt: "2024-02-15", views: 350000 },
    { id: "2-4", number: 4, title: "Forbidden Connection", uploadedAt: "2024-02-22", views: 340000 },
    { id: "2-5", number: 5, title: "The Choice", uploadedAt: "2024-02-29", views: 330000 },
  ],
};

export const COMMENTS: Comment[] = [
  {
    id: "c1",
    author: "SoftReader",
    avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=40&h=40&fit=crop",
    content: "This chapter was absolutely beautiful! The emotional depth is incredible.",
    timestamp: "2 hours ago",
    likes: 234,
    replies: [
      {
        id: "c1-r1",
        author: "ManhwaLover",
        avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=40&h=40&fit=crop",
        content: "I completely agree! The author really knows how to tug at heartstrings.",
        timestamp: "1 hour ago",
        likes: 89,
      },
    ],
  },
  {
    id: "c2",
    author: "RomanceJunkie",
    avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=40&h=40&fit=crop",
    content: "Can't wait for the next chapter! The tension between them is killing me.",
    timestamp: "4 hours ago",
    likes: 156,
  },
  {
    id: "c3",
    author: "ArtisticSoul",
    avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=40&h=40&fit=crop",
    content: "The art style in this series is so unique and captivating. Love it!",
    timestamp: "6 hours ago",
    likes: 198,
  },
];
