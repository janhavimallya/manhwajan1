# BL Manhwa Hub - Design Brainstorm

## Approach 1: Ethereal Minimalism with Soft Gradients
**Design Movement:** Contemporary Minimalism meets Korean Aesthetic
**Probability:** 0.08

**Core Principles:**
- Embrace negative space and breathing room between elements
- Soft, diffused color transitions rather than hard edges
- Typography hierarchy through weight and scale, not color
- Subtle depth through layered shadows and soft glows

**Color Philosophy:**
- Primary palette: Deep charcoal (#1a1a2e) background with soft pastels (rose #f0d9e8, lavender #e8dff5, sky blue #d9e8f5)
- Accent colors emerge from pastel tones, never saturated
- Emotional intent: Calm, introspective, intimate storytelling

**Layout Paradigm:**
- Asymmetric card placement with varied widths (60/40 splits)
- Vertical rhythm with generous spacing (8px, 16px, 32px system)
- Cards float with subtle elevation, creating depth without clutter

**Signature Elements:**
- Soft gradient overlays on cover images (rose to transparent)
- Delicate divider lines using opacity rather than solid borders
- Floating bookmark icons with gentle pulse animations

**Interaction Philosophy:**
- Hover states reveal subtle gradient shifts
- Click interactions trigger soft scale transforms (1 → 1.02)
- Transitions use ease-in-out with 300-400ms duration

**Animation:**
- Entrance animations: Fade-in with slight upward movement (opacity 0→1, translateY 20px→0)
- Hover: Subtle color shift and shadow deepening
- Loading states: Gentle pulsing glow effect
- Scroll triggers: Cards fade in as viewport enters

**Typography System:**
- Display: Playfair Display (serif) for titles—elegant, romantic
- Body: Inter for descriptions—clean, readable
- Accent: Poppins for tags and metadata—modern, friendly

---

## Approach 2: Vibrant Neon Cyberpunk with Bold Contrast
**Design Movement:** Y2K Maximalism meets Cyberpunk Aesthetic
**Probability:** 0.07

**Core Principles:**
- High saturation and bold color blocking
- Geometric shapes and angular layouts
- Typography as visual art, not just information
- Layered, almost chaotic but intentional composition

**Color Philosophy:**
- Primary: Deep purple (#2d1b4e) with neon accents (hot pink #ff006e, cyan #00f5ff, lime #39ff14)
- Emotional intent: Energy, rebellion, youthful passion
- Colors clash intentionally to create visual excitement

**Layout Paradigm:**
- Diagonal cuts and skewed elements using CSS transforms
- Grid-breaking layouts with overlapping cards
- Bold typography that dominates the visual hierarchy

**Signature Elements:**
- Glowing neon borders on interactive elements
- Animated gradient text for titles
- Pixelated or glitchy hover effects

**Interaction Philosophy:**
- Hover states trigger color inversions
- Click animations use scale and rotation (1 → 1.1 with 5deg rotation)
- Transitions are snappy (150-200ms) for energetic feel

**Animation:**
- Entrance: Slide-in from edges with rotation
- Hover: Glow intensification and color shift
- Loading: Spinning gradient animation
- Scroll: Parallax effects with cards moving at different speeds

**Typography System:**
- Display: Space Mono (monospace) for titles—futuristic, bold
- Body: Roboto for descriptions—geometric, modern
- Accent: Courier Prime for tags—technical, edgy

---

## Approach 3: Warm Storytelling with Illustrated Elements
**Design Movement:** Illustration-Driven Design meets Cozy Modernism
**Probability:** 0.06

**Core Principles:**
- Warmth through earthy, muted tones
- Illustrated elements and organic shapes
- Narrative-first design that celebrates storytelling
- Handcrafted feel with subtle imperfections

**Color Philosophy:**
- Primary: Warm cream (#f5f1e8) with terracotta (#c85a54), sage green (#7a9b8e), dusty rose (#d4a5a5)
- Emotional intent: Comfort, warmth, emotional connection
- Colors evoke autumn and intimate moments

**Layout Paradigm:**
- Organic, flowing layouts with rounded elements
- Illustrated dividers and decorative elements between sections
- Asymmetric placement with intentional "imperfections"

**Signature Elements:**
- Hand-drawn style illustrations for category icons
- Watercolor-effect backgrounds on featured sections
- Decorative flourishes (leaves, flowers) in corners

**Interaction Philosophy:**
- Hover states trigger subtle color warming
- Click animations use gentle bounce (cubic-bezier easing)
- Transitions feel natural and organic (400-500ms)

**Animation:**
- Entrance: Fade-in with gentle scale (0.95 → 1)
- Hover: Color shift to warmer tone with slight lift
- Loading: Animated illustration elements (leaves falling, petals floating)
- Scroll: Staggered entrance animations for card rows

**Typography System:**
- Display: Lora (serif) for titles—warm, literary, romantic
- Body: Nunito for descriptions—friendly, approachable
- Accent: Quicksand for tags—playful, rounded

---

## Selected Design: Ethereal Minimalism with Soft Gradients

We are proceeding with **Approach 1: Ethereal Minimalism with Soft Gradients** because it perfectly captures the intimate, romantic nature of BL storytelling while maintaining a modern, sophisticated aesthetic. The soft color palette and generous whitespace create an environment where the manhwa content becomes the focus, and the design supports rather than overwhelms the user experience.

### Design Implementation Details

**Color System:**
- Background: #1a1a2e (deep charcoal)
- Card Background: #252541 (slightly lighter for contrast)
- Accent Rose: #f0d9e8
- Accent Lavender: #e8dff5
- Accent Sky: #d9e8f5
- Text Primary: #f5f5f5
- Text Secondary: #b0b0b0

**Typography:**
- Display Font: Playfair Display (serif)
- Body Font: Inter (sans-serif)
- Accent Font: Poppins (sans-serif)

**Spacing System:**
- xs: 4px
- sm: 8px
- md: 16px
- lg: 32px
- xl: 64px

**Shadow System:**
- Subtle: 0 2px 8px rgba(0,0,0,0.1)
- Medium: 0 4px 16px rgba(0,0,0,0.15)
- Deep: 0 8px 32px rgba(0,0,0,0.2)

**Animation Defaults:**
- Transition Duration: 300-400ms
- Easing: cubic-bezier(0.4, 0, 0.2, 1)
- Entrance: Fade-in + subtle upward movement
